package com.example.bmi;

import com.example.bmi.hello.Person;
import com.example.bmi.hello.Student;

public class Tester
{
    public static void main( String[] args )
    {
        Student stu = new Student("001","alice",60,80);
        Student stu2 = new Student("002","noreen",60,80);
        System.out.println("123");
//        stu.print();
//        stu2.print();
//        stu.setId("001");
//        stu.setName( "alice" );
//        stu.setEnglish( 80 );
//        stu.setMath( 60 );



//        Person person = new Person();
//        person.hello();
//        person.hello("alice");
//        person.hello(123);
//        person.setWeight( 66 );
//        person.setHeight( 1.7f );
//        System.out.println(person.bmi());
    }

}
