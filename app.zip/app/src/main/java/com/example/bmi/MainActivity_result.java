package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity_result extends AppCompatActivity
{
    static public final String advice = "advice";
    public static final String TAG = "noreen";
    public TextView  result_text;

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_result );
        result_text = findViewById( R.id.result_text );
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra( advice );
        Log.d( TAG, "onCreate: " + stringExtra);
        result_text.setText( stringExtra );
    }
}
