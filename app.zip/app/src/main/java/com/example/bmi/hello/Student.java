package com.example.bmi.hello;

import android.util.Log;

public class Student
{
    public static int pass = 60;
    String id;
    String name;
    int math;
    int english;

    public Student( String id, String name, int math, int english )
    {
        this.id = id;
        this.name = name;
        this.math = math;
        this.english = english;
    }

    public void print(){
        Log.d( "123", "print: "+ id + name + math + english + getAverge());
        if ( getAverge() < pass){
            Log.d( "123", "print: 平均沒有到60" );
        }else{
            Log.d( "123", "print: 還可以" );
        }
    }

    private int getAverge(){
        return (math + english)/2;
    }

    public String getId()
    {
        return id;
    }

    public void setId( String id )
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public int getMath()
    {
        return math;
    }

    public void setMath( int math )
    {
        this.math = math;
    }

    public int getEnglish()
    {
        return english;
    }

    public void setEnglish( int english )
    {
        this.english = english;
    }
}
