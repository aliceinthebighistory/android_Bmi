package com.example.bmi;

import androidx.annotation.LongDef;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity
{
    private EditText m_weightEdit;
    private EditText m_heightEdit;
    public static final String TAG = "noreen";
    public float result;
    public String str;
    public TextView m_result_text;
    public String advice;
    private Object MainActivity;
    private TextView weightTag;
    private TextView heightTag;

    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d( TAG, "onCreate: " + "this is onStart");
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        Log.d( TAG, "onCreate: " + "this is onStop");
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.d( TAG, "onCreate: " + "this is onDestroy");
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        Log.d( TAG, "onCreate: " + "this is onPause");
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Log.d( TAG, "onCreate: " + "this is onResume");
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.d( TAG, "onCreate: " + "this is onRestart");
    }

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        m_weightEdit = findViewById( R.id.weightEdit );
        m_heightEdit = findViewById( R.id.heightEdit );
        m_result_text = findViewById( R.id.result_text );
        weightTag = findViewById( R.id.weightTag );
        heightTag = findViewById( R.id.heightTag );

        weightTag.setText( R.string.weightTag );
        heightTag.setText( R.string.heightTag );
        m_weightEdit.setHint( R.string.weight );
        m_heightEdit.setHint( R.string.height );

        Log.d( TAG, "onCreate: " + "this is oncreate");

//start按鈕計算
        Button calculate = findViewById( R.id.calculate );
        calculate.setText( R.string.calculate );
        calculate.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick( View view )
            {
                int weight = Integer. parseInt(m_weightEdit.getText().toString());
                float height = Integer. parseInt(m_heightEdit.getText().toString());
                //多國語系
                String hello = getResources().getString( R.string.hello );
                height = height/100;
                height = (float) Math.pow (height , 2);
                // 體重(公斤) / 身高2(公尺2)
                result = weight/height;
                DecimalFormat frmt = new DecimalFormat("#.##");
                String aa = frmt.format( result );
                m_result_text.setText( aa );


                Toast.makeText( MainActivity.this, "your bmi is" + aa, Toast.LENGTH_LONG ).show();
                    new AlertDialog.Builder( MainActivity.this )
                            .setTitle( "BMI" )
                            .setMessage( "Your BMI is" + aa)
                            .setPositiveButton( "OK", new DialogInterface.OnClickListener()
                            {
                                @Override
                                public void onClick( DialogInterface dialogInterface, int i )
                                {
                                    m_weightEdit.setText( "" );
                                    m_heightEdit.setText( "" );
                                }

                            } )
                            .show();
            }
        } );




//help按鈕跳頁給意見
        Button help = findViewById( R.id.help );
        help.setText( R.string.help );
        help.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick( View view )
            {
                //if else判斷健康與否

                if(result < 18.5){
                    advice = getString( R.string.tooLight);
                }else if(result >= 18.5 && result < 24){
                    advice = getString( R.string.healthy);
                }else if(result >= 24 && result < 27){
                    advice = getString( R.string.overWight);
                }else if(result >= 27 && result < 30){
                    advice = getString( R.string.overWeightL1);
                }else if(result >= 30 && result < 35){
                    advice = getString( R.string.overWeightL2);
                }else{
                    advice = getString( R.string.overWeightL3);
                }

                Intent intent = new Intent(MainActivity.this, MainActivity_result.class);


                intent.putExtra( MainActivity_result.advice, advice );
                startActivity( intent ); //寫按鈕必備
            }
        } );
    }
}